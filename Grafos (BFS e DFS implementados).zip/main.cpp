#include "grafo.h"





int main(){

    Grafo g1;

    g1.ler_grafo("grafinho.txt");
    cout << "===== LISTA DE ADJACÊNCIA=====" << endl;
    g1.imprimir_listaadj();
    cout << endl;
    cout << "===== BFS =====" << endl;
    g1.bfs(0);
    cout << "===== DFS =====" << endl;
    g1.dfs(0);

    return 1;
}