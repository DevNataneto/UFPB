#include <iostream>
#include "pilha.h"
#include "pilhadinamica.h"

using namespace std;

int main(){

    Pilha p1;
    Pilhadinamica p2;
    cout << "===== Teste pilha estatica =====" << endl;
    p1.empilhar(10);
    p1.empilhar(25);
    p1.empilhar(35);
    p1.empilhar(15);
    p1.empilhar(50);
    p1.desempilhar();
    cout << p1.get_topo() << endl;
    cout << "===== Teste pilha dinamica =====" << endl;
    p2.empilhar(5);
    p2.empilhar(5);
    p2.empilhar(5);
    p2.empilhar(55);
    p2.empilhar(25);
    p2.empilhar(32);
    p2.empilhar(50);
    p2.desempilhar();

    cout << p2.get_topo() << endl;
    cout << p2.get_tamanho() << endl;

    





    return 1;
}