#ifndef LISTA_ENCAD_H
#define LISTA_ENCAD_H

class no{
    int dado;
    no *prox;
public:
    no(int d);
    int get_dado();
    no* get_prox();
    void set_dado(int d);
    void set_prox(no *p);
};

class lista{
    int tamanho;
    no *head;
public:
    lista();
    bool vazia();
    int get_tamanho();
    int elemento(int pos);
    int pos(int dado);
    bool inserir(int pos, int dado);
    bool inserirInicio(int dado);
    bool inserirFim(int dado);
    bool inserirMeio(int pos, int dado);
    bool remover(int pos);
    bool removeInicio();
    bool removeLista(int pos);
};



#endif